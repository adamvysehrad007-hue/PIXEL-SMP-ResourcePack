PIXEL SMP - Rank Badges (Java Edition 26.3)

This resource pack adds seven small colored rank badges as custom font glyphs.
It is intended for LuckTAB 2.9.0 icons-auto.

Files:
- assets/minecraft/font/default.json
- assets/minecraft/textures/font/rank_*.png
- pack.mcmeta

LuckTAB config:
icons-auto:
  enabled: true
  pack: "plugins/LuckTAB/PIXEL_SMP_Rank_Badges.zip"

Prefix examples (use these in the LuckTAB prefixes section):
- "majitel;:rank_majitel: ;;&4"
- "admin;:rank_admin: ;;&5"
- "moderator;:rank_moderator: ;;&9"
- "helper;:rank_helper: ;;&b"
- "vipplus;:rank_vipplus: ;;&e"
- "vip;:rank_vip: ;;&6"
- "player;:rank_player: ;;&a"

Important:
1. LuckTAB can read the local ZIP using icons-auto.pack.
2. Players must also receive this same ZIP as their Minecraft server resource pack.
3. The server resource-pack setting needs a direct HTTPS download URL and (recommended) its SHA-1.
4. This pack targets Java Edition 26.3. Bedrock/Geyser clients may need a separate compatible pack and should be tested separately.
